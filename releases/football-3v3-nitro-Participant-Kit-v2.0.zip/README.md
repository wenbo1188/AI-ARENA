# 足球 3v3 氮气赛 · 选手开发包 v2.0

阅读完整参赛说明（MD / TXT 任选其一），修改 entry/bot.py。

```text
python kit.py match
python kit.py match --seat right
python kit.py check
```

check 默认使用本项完整长度、公开种子换边两局。需要短程调试可用 check --ticks 180（旅人用 --rounds 3），短程结果不是完整准入凭证。
最终只交 bot.py 和自由格式策略说明文档，不要求打包、自测报告或元信息。主办方独立复测。
这是本地开发工具，不提供完整禁网和跨选手文件隔离。正式比赛由主办方统一评测。
