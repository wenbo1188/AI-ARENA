# 游戏机制与接口源文档

正式规则由根目录 RULES.md 统一生成；本文件只维护游戏机制、协议与数值。

## 本届HP与奥义规则

全员99级，无装备和坚果。每名角色先按基础属性、副职百分比加成和支援技能计算最大HP，最后固定增加 **1000 HP**，并以这个最终最大HP满血开局；此项不占JP、金钱或支援技能槽位。固定增加值不再乘副职百分比，不限制HP为9999。

`init.travelers[*].hp` 和旅人属性表中的HP是未配置的基础HP，不包含这项固定增加值。`init.arena_rules.hp_bonus` 公布固定增加值；战斗观测中的 `max_hp`、回放中的 `unit_max` 是配置和固定增加后的最终值。

满足SP、BP及技能条件时，**第一回合即可使用职业奥义**。奥义需要3 BP；开局满潜力支援保持满潜力。第一回合按正常伤害公式结算。按最大HP比例计算的恢复、复活、中毒、潜力增长和回合上限判定均使用最终最大HP。

## 对局流程

一场比赛由很多"步"（tick）组成，每一步是一次决策：

1. **选人阶段**：从 8 名旅人中选 `team_size`（默认 4）人。
   - `pick_mode = "blind"`（默认）：tick 0 双方**同时**一次选完 4 人，看不到对方选了谁，**两队可以选相同的旅人**（同一队内不能重复）。
   - 你选的顺序就是队员 id（0、1、2、3）。
2. **赛前配置阶段**（一步）：双方**同时**提交配置：每人的副职业、用 JP 学的副职技能、支援技能，以及全队带进战斗的道具。
   两队的**预算完全相同**（全队共用的 JP 和金钱），提交时**看不到对手的配置**（blind 选人时连对手选了谁也看不到），战斗开始时双方配置公开。
3. **战斗阶段**：每一步是**某一个角色的一次行动**。轮到你的角色行动时 `your_turn` 为 true，你给出这个角色的行动；其余步你只需回 `{"tick": t}`。
4. 一方全员倒下时比赛结束。达到 `max_rounds`（默认 30）回合仍未分出胜负时，比较双方"每个队员剩余 HP / 最大 HP"的总和，高者胜，相同为平局。
   引擎结果值胜1、平0.5、负0，仅用于辨认胜负；总榜每局换算为胜3、平1、负0。

## 通信协议

所有消息都是单行 JSON。

### 1. 开局（init）

```json
{"type": "init", "time_limit_ms": 1000, "total_time_ms": 60000, "time_budget_type": "cpu_user_system", "game": "octopath", "you": 0, "team_size": 4, "pick_mode": "blind",
 "max_rounds": 30, "max_bp": 5, "max_boost": 3,
 "arena_rules": {"hp_bonus": 1000, "hp_bonus_order": "after_loadout", "divine_first_round": true},
 "travelers": {"hikari": {"name": "光", "name_en": "Hikari", "job": "剑士", "job_en": "Warrior", "hp": 5781, "sp": 145, "pa": 342, "pd": 313,
                          "ea": 256, "ed": 228, "acc": 313, "eva": 228, "crit": 285, "spd": 285,
                          "weapons": ["sword", "polearm"], "shields": 7, "weak": ["axe", "bow", "ice", "wind"],
                          "skills": ["aggressive_slash", "..."], "latent_power": {"name": "阴之力", "desc": "..."},
                          "latent_skills": ["tenretsu", "hien", "sougetsu"]}, "...": "..."},
 "skills": {"aggressive_slash": {"job": "Warrior", "name": "Aggressive Slash", "zh": "五月雨斩", "sp": 9, "target": "random",
                                 "kind": "phys", "type": "sword", "power": 0.9, "boost": "hits", "levels": [3, 4, 5, 6], "desc": "..."}, "...": "..."},
 "concoct_recipes": {"elixir": {"zh": "复苏药", "desc": "..."}, "...": "..."},
 "types": ["sword", "polearm", "dagger", "axe", "bow", "staff", "fire", "ice", "lightning", "wind", "light", "dark"],
 "constants": {"level_multiplier": 1.36328125, "weak_mult": 1.3, "break_mult": 2.0, "crit_mult": 1.25, "defend_mult": 0.5, "...": "..."},
 "loadout_enabled": true,
 "loadout_rules": {"budget": {"jp": 12000, "gold": 6000},
                   "jp_costs": [30, 100, 500, 1000, 3000, 5000], "free_skills": 2, "support_unlock": [4, 5, 6, 7],
                   "support_slots": 4, "licenses": 3,
                   "jobs": {"Warrior": {"zh": "剑士", "bonus_pct": {"hp": 18, "pa": 5, "pd": 5}, "weapons": ["sword", "polearm"],
                                        "skills": ["aggressive_slash", "..."], "free_skills": ["aggressive_slash", "piercing_thrust"],
                                        "divine": "brands_blade", "supports": ["bolstering_break", "summon_strength", "latent_power_plus", "deal_more_damage"]}, "...": "..."},
                   "supports": {"summon_strength": {"job": "Warrior", "n": 2, "zh": "物攻+50", "desc": "...", "battle": true}, "...": "..."},
                   "items": {"healing_grape": {"name": "Healing Grape", "zh": "...", "price": 50, "target": "ally", "fx": {"hp": 500}, "desc": "..."}, "...": "..."},
                   "item_stack": 99}}
```

必须回复 `{"ready": true}`。init 传递已冻结的正式参数；与正式参赛说明不一致时按评测异常复核，不得临时调整玩法。

### 2. 选人阶段的每一步

```json
{"type": "turn", "tick": 0, "phase": "pick", "your_turn": true, "pick_count": 4, "pick_mode": "blind",
 "available": ["hikari", "agnea", "partitio", "osvald", "temenos", "throne", "ochette", "castti"],
 "my_picks": [], "opponent_picks": []}
```

轮到你时回复 `pick_count` 个旅人 key（顺序 = 队员 id）：

```json
{"tick": 0, "pick": ["temenos", "osvald", "hikari", "throne"]}
```

选人名单数量、类型或 ID 错误属于当前 tick 协议错误；本步引擎随机补齐，后续合法回复可继续控制。

### 3. 赛前配置（选人结束后的一步）

```json
{"type": "turn", "tick": 1, "phase": "loadout", "your_turn": true, "my_picks": ["temenos", "osvald", "hikari", "throne"],
 "opponent_picks": [], "budget": {"jp": 12000, "gold": 6000}}
```

`opponent_picks` 只在 draft 选人时有内容（blind 时你不知道对手是谁）。回复 `loadout`（按队员 id 顺序的列表，也可以用 `{"0": {...}, "1": {...}}`，每人一份）和 `items`（全队的道具袋）：

```json
{"tick": 1, "loadout": [
  {"sub_job": "Scholar", "learn": ["lightning_bolt", "stroke_of_genius", "elemental_barrage", "advance_magic"],
   "supports": ["rise_again", "elemental_augmentation", "resilience", "inner_strength"]},
  {"...": "..."}, {"...": "..."}, {"...": "..."}],
 "items": {"healing_grape": 10, "olive_of_life": 3}}
```

| 字段 | 说明 |
|---|---|
| `sub_job` | 副职业，8 个基础职业之一（`Warrior` `Merchant` `Thief` `Apothecary` `Hunter` `Cleric` `Scholar` `Dancer`）。不能和本职相同；每个职业只有 3 张执照，一队最多 3 人选同一个副职。不填 = 没有副职 |
| `learn` | 用 JP 学的副职技能 id。副职的 2 个初始技能（`free_skills`，原作的默认技能）自动学会，不用写。每个职业和原作一样有 8 个技能；偷窃、收集金钱、雇佣帮手、分析（`nonbattle_skills`）在对战里没有效果，但同样可以花 JP 学，也算进"会几个技能"。价格按**学的顺序**算：第 1 个 30、第 2 个 100、500、1000、3000，神技 5000，且神技要先学会其他全部技能。全队 4 人的花费加起来不能超过 `budget.jp` |
| `supports` | 最多 4 个支援技能 id。本职的 4 个支援技能都能装（旅人本职已经精通）；副职的第 1～4 个支援技能在副职会 4/5/6/7 个技能（含免费的 2 个）时解锁。`battle: false` 的支援技能只在原作探索时有用，不能装 |
| `items` | `{道具 id: 个数}`，全队共用一个道具袋，每种最多 `item_stack` 个，总价（价格见下方"道具"表）不能超过 `budget.gold`。战斗中任何队员都可以用，用掉就少一个 |

**不合法时**：单个条目不合法（未知 id、栏位已满、支援技能没解锁等）只忽略那一条；JP 或金钱的**全队总花费超预算，全队这一项全部作废**（JP 超了没有副职技能，金钱超了不带道具）；不回复或超时，全队都没有配置。被忽略的内容会出现在事件 `loadout` 的 `notes` 里。

**属性怎么算**：`配置属性 = 基础属性 × (1 + 副职加成%) + 支援技能固定加值`；最大 HP 在此后再固定增加 1000。本竞技场**没有装备和坚果**。

### 4. 战斗阶段的每一步

```json
{"type": "turn", "tick": 5, "phase": "battle", "round": 2, "your_turn": true, "actor": 1,
 "me": [ {单位}, {单位}, {单位}, {单位} ],
 "opponents": [ {单位}, ... ],
 "current": [0, 1],
 "queue": [[1, 2], [0, 3]],
 "next_round_order": [[0, 0], [1, 2], ...],
 "available_skills": [{"id": "attack", "sp": 0, "usable": true}, {"id": "fireball", "sp": 14, "usable": true}, ...],
 "my_items": {"healing_grape": 9, "olive_of_life": 3}, "opponent_items": {"...": 1},
 "usable_items": ["healing_grape", "olive_of_life"],
 "last_events": [ ... ]}
```

- `actor`：这一步要行动的**己方**队员 id（不轮到你时为 null）。
- `current`：当前行动者 `[阵营, id]`，**阵营 0 = 你，1 = 对手**（所有 `[阵营, id]` 都是这个约定）。
- `queue`：本回合在当前行动者之后、还没行动的角色顺序（被击破/倒下的已移除）。
- `next_round_order`：按当前速度和优先级预估的下回合顺序（不含随机浮动，仅供参考）。
- `available_skills`：当前行动者能选的全部行动和是否可用（SP 够不够、潜力是否就绪、材料是否够），包括学会的副职技能。
- `my_items` / `opponent_items`：双方道具袋里还剩的道具（用完的不再出现）。`usable_items`：当前行动者现在能用的道具（复活类道具要有倒下的队友才能用）。
- `last_events`：上一步发生的事件（见下文"事件"），方便你追踪对手做了什么。

**单位**的字段：

```json
{"id": 1, "traveler": "osvald", "name": "奥兹巴尔多", "alive": true,
 "hp": 4557, "max_hp": 4557, "sp": 218, "max_sp": 218, "bp": 1,
 "shields": 5, "max_shields": 5, "weaknesses": ["sword", "dagger", "fire", "lightning"],
 "broken": false, "broken_until_round": null,
 "latent": 35.5, "latent_ready": false, "weapons": ["staff"],
 "stats": {"pa": 256, "pd": 256, "ea": 370, "ed": 342, "spd": 256, "crit": 228, "acc": 285, "eva": 285},
 "buffs": {"ea": 3}, "debuffs": {}, "status": {"poison": 2}, "defending": false,
 "spell_tier": 1, "spell_tier_charges": 0, "boosted_this_round": false, "materials": 4,
 "sub_job": "Cleric", "skills": ["fireball", "...", "heal_wounds", "holy_light"], "supports": ["elemental_augmentation", "..."],
 "rise_again_ready": false}
```

- `stats` 是**已计入副职、支援技能和增益/减益**后的当前值。`weapons` 是能用的武器类型（本职 + 副职），武器只决定攻击类型，不加属性。
- `sub_job` / `skills` / `supports`：赛前配置的结果（双方公开）；`rise_again_ready`：支援技能"自动复活"还没用掉。`buffs` / `debuffs` 是 `{属性: 剩余次数}`。
- `status` 里可能出现：`poison` 中毒、`poison_weak` 弱毒、`immune` 异常免疫、`taunt` 挑衅、`counter` 反击剩余次数、`sidestep` 闪避剩余次数、`sacred` 圣盾减伤百分比、`regen` 持续恢复、`leghold` 捕兽夹、`extra` 祝福（回合末额外行动）、`spread` 魅惑（单体变全体）、`charity` 慈悲、`ward` 预防药（还能挡几次属性下降）。
- `broken_until_round`：被击破的单位在这一回合开始时恢复。
- `materials` 只有卡斯蒂（castti）有（调合材料数）。
- 双方信息完全公开（包括对手的弱点、护盾、SP、BP）。

轮到你时回复：

```json
{"tick": 5, "action": {"skill": "fireball", "target": 2, "boost": 2, "latent": false}}
```

| 字段 | 说明 |
|---|---|
| `skill` | `"attack"`（普通攻击）、`"defend"`（防御）、`"item"`（使用道具）、`"concoct"`（卡斯蒂的调合）、该旅人的技能 id，或潜力专属技能 id |
| `target` | 目标 id：对敌技能填对手 id，对己方技能填己方 id；全体/随机/自身技能可省略 |
| `targets` | 只对 target 为 `chosen` 的技能（狙击）有效：每一击的目标 id 列表，不够的次数重复最后一个；省略时全部打 `target` |
| `boost` | 0～3，花多少 BP 加成（超过现有 BP 会被截断）。防御和没有加成效果的技能不能加成，不会扣 BP。神技固定花 3 BP，不看这个字段 |
| `latent` | true 表示本次行动先发动潜力（需要 `latent_ready`） |
| `weapon` | 只对普通攻击有效：用哪种武器（必须是该角色 `weapons` 之一，默认第一种） |
| `recipe` | 只对调合有效：`elixir` / `phoenix` / `toxin` / `firebomb` |
| `item` | 只对 `"skill": "item"` 有效：道具 id，必须在 `usable_items` 里 |

**默认行动**：当前 tick 超时或协议格式错误时，引擎普通攻击对方第一个活着的角色，不采纳非法回复的 target 或 boost；下个 tick 可恢复控制。回复结构合法但技能不存在、不属于角色、SP 不够或道具不可用时，按引擎游戏规则回退普通攻击，合法 target 与 boost 依引擎处理。崩溃、初始化失败或整局预算耗尽后，本局持续默认接管、不重启。

### 5. 结束（end）

```json
{"type": "end", "scores": [1, 0]}
```

## 战斗规则

### 回合与行动顺序

- 每回合开始时，所有活着且未被击破的角色排成行动顺序：先按优先级（上回合**防御**过的最先；被**捕兽夹**的最后；其他居中），同优先级按 `速度 × (1 ± speed_jitter)` 从高到低（`speed_jitter` 默认 0.08，即每回合有 ±8% 的随机浮动）。
- **激励**（Stimulate）可以把队友在队列里的位置提前；如果该队友本回合已经行动，则提前他下回合的位置。
- 所有人行动完后，有**祝福**（艾尔弗里克的祝福）状态的角色在回合末各额外行动一次，然后进入下一回合。
- 盗贼的潜力「残影」会让她在本次行动后立刻再行动一次。

### BP 与加成（Boost）

- 每个角色开局 1 BP，上限 5。从第 2 回合起，每回合开始时，活着且未被击破的角色 +1 BP，**但上一回合用过加成的角色这回合不加**（原作规则）。
- 每次行动最多花 3 BP。**神技（★）只能以最大加成发动**（原作规则）：必须有至少 3 BP，发动时固定消耗 3 BP，效果已按最大加成设计；BP 不足 3 时神技不可用（商人发动潜力补满 BP 的同一次行动可以用）。
- 其他技能按 `boost` 字段决定加成效果，`levels` 是 0/1/2/3 BP 时的数值：
  - `power`：威力（或恢复量）×(1 + BP)。
  - `hits`：攻击次数取 `levels[BP]`（元素乱射是区间，随机取）。
  - `crit`：暴击率取 `levels[BP]` %。
  - `dur`：持续次数取 `levels[BP]`。
  - `count`：次数/数量/百分比取 `levels[BP]`。
- 普通攻击：每 1 BP 多打 1 下（BP 3 = 4 连击）。
- 被击倒会失去全部 BP。

### 伤害与治疗

常规攻击每击按下面的公式计算，具体参数以开局技能表和 `verified_values.json` 为准：

```
基础伤害 = (min(999,攻击) × invocation - min(999,防御)/2) × ability_ratio × 1.36328125
最终伤害 = 基础伤害 × 增减益倍率 × 技能特殊倍率 × 状态倍率 × 暴击倍率 × 防御倍率 × 随机(1.01～1.05)
```

`invocation_values[BP]` 和 `ability_ratios[BP]` 给出四档参数；神技按BP=3取值。普通攻击invocation=1、ability_ratio=0.8，加成增加攻击次数。全员使用99级属性与等级伤害系数1.36328125。
物理攻击使用基础物攻和目标基础物防；魔法使用基础属攻和目标基础属防。观测中的 `base_stats` 给出这些基础值，含副职与支援技能加值，不含战斗中的攻防增减益。攻方攻击上升×1.5、下降×2/3；目标防御下降×1.5、上升×2/3，作用于伤害而非先改基础攻防。
状态倍率：目标击破中为2；否则命中弱点为1.3；否则为1。弱点和击破不叠乘。物理暴击通常×1.25，消除增益的剑技为×1.2；魔法不暴击。防御中×0.5；圣盾另乘其减伤比例。
最终伤害最低1（完全减伤可以为0），每击取整，伤害上限9999，突破伤害界限时99999。无属性攻击不命中武器或元素弱点。
治疗使用施术者基础属防×恢复invocation×ability_ratio×等级系数×恢复支援倍率×0.98～1.02随机值，不使用属攻或属防增益。数据详见 `verified_values.json`。道具固定效果另行计算。
盗贼神技以物攻计算，再乘(0.84+当前速度/500)；学者潜力使适用的全体魔法集中为单体并使伤害×2。
物理命中率 = clamp(round(50×(3−目标回避/自身命中)+招式命中补正,3)/100,0.2,1)；普通攻击补正20，其他招式见 `hit_ratios[BP]`。击破目标无自然闪避。自然暴击率 = clamp((自身暴击−目标速度)/200,0,1)。上述命中、回避、暴击和速度使用战斗增减益后的属性。本届回避率上升支援使落空率额外增加20个百分点；击破中的目标仍无自然闪避。陷阱触发后随机减益持续2回合。

### 护盾、弱点与击破（Break）

- 每个旅人有固定的护盾数和 4 个弱点（见下表；原作中旅人不会成为敌人，护盾和弱点是本竞技场的设计）。
- 每一击如果攻击类型（`type`，武器或属性）是目标的弱点，目标护盾 -1。带 `shield_break` 的技能每击额外削对应数量，无视弱点。
- 护盾归零即**击破**：
  - 如果本回合还没行动，失去本回合的行动；**下一回合也不能行动**；
  - 击破期间受到的伤害 ×`break_mult`（2.0），护盾不再减少，不回复 BP；
  - 在 `broken_until_round` 那一回合开始时恢复，护盾回满。
- 被击倒的角色复活后护盾回满。

### 状态持续时间

文档里写的"N 回合"实际按**该角色自己的行动次数**计算：每次该角色行动结束后，它身上的增益、减益、中毒、弱毒、免疫、挑衅、持续恢复、捕兽夹、魅惑、慈悲各减 1（被击破期间不行动，所以不会减少）。祝福（extra）每回合末使用一次减 1。
行动结束后依次结算：持续恢复（最大 HP 的 `regen_pct`），中毒（最大 HP 的 `poison_pct`，可能致死；弱毒时每次中毒结算削1盾，不增加中毒伤害）。

### 魔法强化

只有技能表 `spell: true` 的技能消耗强化次数：学者三种全体元素魔法、光明魔法、恢复魔法、复活魔法。二阶、三阶使用 `tier_parameters[阶数-1][BP]` 的独立参数；全体攻击魔法分别打2次、3次。单体元素魔法与属性混乱不受魔法强化影响。
大魔法化提供2/3/4/5次强化，硕学王的知识提供3次；施术者的魔法强化加成支援另加1次。

### 潜力（Latent Power）

- 潜力显示为0～100%的归一化能量；`latent_capacity` 为原始容量：欧修缇、爱格妮娅、提米诺斯、光125，其余100。受伤获得floor(130×实际扣血/最大HP)原始能量，击破获得25；普通行动本身不加能量。支援技能增加的原始能量也按个人容量换算百分比。
- 能量满 100（`latent_ready`）时，行动里写 `"latent": true` 即在本次行动开始时发动，能量清零。发动潜力不占行动，之后照常执行 `skill`（也可以同时加成）。
- 各旅人的潜力：

| 旅人 | 潜力 | 本竞技场的效果 |
|---|---|---|
| 光 hikari | 阴之力 | 本次行动可以使用 `tenretsu` 天裂斩 / `hien` 飞燕华 / `sougetsu` 双月闪（不消耗 SP） |
| 爱格妮娅 agnea | 齐心协力 | 本次行动的单体技能（含普通攻击、单体辅助）改为作用于全体 |
| 帕特提欧 partitio | 气势 | BP 立刻补满 5，再执行行动（可以接着加成） |
| 奥兹巴尔多 osvald | 魔法集合化 | 本次的全体攻击魔法只打你指定的一个敌人，伤害 ×2 |
| 提米诺斯 temenos | 审判 | 本次行动的每一击都削 1 护盾，无视弱点 |
| 斯洛妮 throne | 残影 | 本次行动后立刻再行动一次 |
| 欧修缇 ochette | 兽之力 | 本次行动可以使用 `beast_claw` 兽之爪 / `beast_fang` 兽之牙 / `beast_roar` 兽之咆哮（不消耗 SP） |
| 卡斯蒂 castti | 节约 | 本次调合不消耗材料，并按 BP 3 的效果生效（不花 BP） |

### 调合（卡斯蒂专属）

`"skill": "concoct"` 消耗 1 份材料（开局 `materials` 份，默认 4），不消耗 SP，可以加成（威力 ×(1+BP)）：

| recipe | 名称 | 效果 |
|---|---|---|
| `elixir` | 复苏药 | 全体队友恢复最大 HP 15%×(1+BP) |
| `phoenix` | 还魂药 | 复活一名倒下的队友（target 填队友 id），恢复最大 HP 25%×(1+BP)；没有倒下队友时改为治疗该队友 |
| `toxin` | 毒雾 | 全体敌人受到 0.5×(1+BP) 倍威力的无属性伤害，并中毒 3 回合 |
| `firebomb` | 火焰瓶 | 全体敌人受到 0.9×(1+BP) 倍威力的火属性伤害（削护盾） |

### 道具

`"skill": "item"` 加 `"item": 道具 id`：从全队道具袋里用掉 1 个，任何队员都能用，不消耗 SP，**不能加成**（原作规则，`boost` 被忽略，不扣 BP）。目标：

- `ally`：单个己方（`target` 填己方 id，默认自己）；`allies`：全体己方。
- `ko`：倒下的己方（`target` 填 id；不填或填了活着的人时，复活第一个倒下的队友）。没有倒下的队友时不能用。
- `enemy`：单个敌人（受挑衅影响）；`enemies`：全体敌人。
- 攻击道具（精灵石）造成**固定伤害**：不看双方属攻/属防，也不乘弱点、击破、防御倍率（圣盾照样减伤），但打中弱点会削 1 护盾。

道具表见文末"道具"。

### 防御

`"skill": "defend"`：直到自己下次行动前，受到的伤害 ×`defend_mult`（0.5）；下回合最先行动。

## 事件（last_events）

每步结束后的事件列表，`u` 是发起者、`t` 是目标，都是 `[阵营, id]`（0 = 你）：

| e | 含义 |
|---|---|
| `pick` | 选人结果 `{"team", "picks", "auto"}` |
| `round` / `order` | 新回合开始 `r`，行动顺序 `o` |
| `turn` | `u` 开始行动 |
| `latent` / `boost` | 发动潜力 / 加成 `n` BP |
| `skill` | 使用技能 `s`（普通攻击带武器 `w`，调合带配方 `r`，道具 `s = "item"` 带道具 id `it`） |
| `hit` | 一击：伤害 `d`，类型 `ty`，`w`=打中弱点，`c`=暴击，`miss`=落空，`dodge`=被闪避 |
| `shield` / `break` / `recover` | 护盾剩余 `v` / 被击破 / 击破恢复 |
| `ko` / `revive` / `heal` | 倒下 / 复活（HP `v`）/ 恢复 `v` |
| `buff` | 属性 `st` 上升（`up`=1）或下降，持续 `r` |
| `status` / `dispel` | 获得状态 `k` / 被解除 `n` 个增益 |
| `poison` / `counter` / `sp` / `bp` / `grace` | 中毒伤害 / 反击 / SP 变化 / BP 变为 `v` / 迷惑之舞效果 `k` |
| `cure` | 道具治好了 `t` 的中毒、弱毒（`n` 个） |
| `loadout` | 赛前配置结束 `{"team", "notes"}`，`notes` 是被忽略的内容 |
| `sup` | 支援技能 `k` 在 `u` 身上触发（坚持到底、自动复活、顺便战斗、陷阱、破防追击等） |
| `end` | 比赛结束 `winner`（0 = 你，1 = 对手，-1 = 平局） |

## 赛前配置数据

下表是本届赛事使用的配置、价格与效果。接口以英文ID为准，中文名仅作说明。

### 职业（副职）

| 职业 | 副职加成 | 武器 | 初始技能（免费） | 神技 | 对战里无效果的技能 | 支援技能（第 1～4 个） |
|---|---|---|---|---|---|---|
| `Warrior` 剑士 | HP+18%，物攻+5%，物防+5% | sword, polearm | `aggressive_slash`, `piercing_thrust` | `brands_blade` | — | `bolstering_break`, `summon_strength`, `latent_power_plus`, `deal_more_damage` |
| `Merchant` 商人 | HP+8%，SP+8%，物攻+3%，物防+3%，属攻+3%，属防+3% | polearm, bow | `arrow_of_fortune`, `rest` | `bifelgans_bounty` | `collect` 收集金钱, `hire_help` 雇佣帮手 | `grows_on_trees`, `boost_start`, `hang_tough`, `full_power` |
| `Thief` 盗贼 | 物攻+2%，命中+5%，速度+8%，暴击+5%，回避+8% | dagger, sword | `steal`（无效果）, `darkest_night` | `aebers_reckoning` | `steal` 偷窃 | `incidental_attack`, `fleetfoot`, `ensnare`, `life_in_the_shadows` |
| `Apothecary` 药师 | HP+20%，物攻+2%，物防+2%，属攻+2%，暴击+2% | axe | `healing_touch`, `icicle` | `dohters_charity` | — | `vigorous_victor`, `hale_and_hearty`, `inspiriting_break`, `preventative_measures` |
| `Hunter` 猎人 | 物攻+8%，命中+6%，速度+5%，暴击+6%，回避+3% | bow, axe | `precise_shot`, `thunderbird` | `draefendis_bow` | — | `heighten_senses`, `eagle_eye`, `more_rare_monsters`, `salt_the_wound` |
| `Cleric` 神官 | SP+18%，属攻+5%，属防+5% | staff | `heal_wounds`, `holy_light` | `aelfrics_blessing` | — | `resilience`, `inner_strength`, `evil_ward`, `rise_again` |
| `Scholar` 学者 | SP+13%，属攻+10%，属防+5% | staff | `fireball`, `icewind` | `alephans_wisdom` | `analyze` 分析 | `evasive_maneuvers`, `elemental_augmentation`, `extra_experience`, `advanced_magic_master` |
| `Dancer` 舞娘 | 属攻+8%，速度+10%，回避+10% | dagger | `lion_dance`, `ruinous_kick` | `sealticges_seduction` | — | `the_show_goes_on`, `ever_evasive`, `hard_worker`, `invigorate_and_inspire` |

### 支援技能

| id | 职业 | 第几个 | 名称 | 效果 |
|---|---|---|---|---|
| `bolstering_break` | 剑士 | 1 | 令敌人破防提升物攻 Bolstering Break | 自己击破敌人时，自身物攻上升 2 回合 |
| `summon_strength` | 剑士 | 2 | 物攻+50 Summon Strength | 物攻 +50 |
| `latent_power_plus` | 剑士 | 3 | 提升潜力上升量 Latent Power Plus | 潜力能量积累速度 ×1.2 |
| `deal_more_damage` | 剑士 | 4 | 突破伤害界限 Deal More Damage | 自己造成的伤害上限从 9999 提高到 99999 |
| `the_show_goes_on` | 舞娘 | 1 | 强化回合数增加 The Show Goes On | 自己施加的属性上升多持续 1 回合 |
| `ever_evasive` | 舞娘 | 2 | 回避率上升 Ever Evasive | 被物理攻击时的落空率 +20%（直接加在落空率上） |
| `hard_worker` | 舞娘 | 3 | 获得JP上升 Hard Worker | ~~战斗后获得的 JP ×1.1（探索用，竞技场无效）~~ 不能装备 |
| `invigorate_and_inspire` | 舞娘 | 4 | 暖场高手 Invigorate and Inspire | 自己施加属性上升时，获得增益的角色潜力能量 +5/10/15/20（按这次行动花的 BP 0/1/2/3） |
| `grows_on_trees` | 商人 | 1 | 获取金额上升 Grows on Trees | ~~战斗后获得的金钱 ×1.1（探索用，竞技场无效）~~ 不能装备 |
| `boost_start` | 商人 | 2 | BP加成 Boost-Start | 开战时 BP +1 |
| `hang_tough` | 商人 | 3 | 坚持到底 Hang Tough | 受到致命的一击时，如果这一击之前 HP 在 25% 以上，剩 1 HP 撑住（多段攻击每一击单独判断） |
| `full_power` | 商人 | 4 | 潜力爆发MAX Full Power | 开战时潜力能量全满 |
| `evasive_maneuvers` | 学者 | 1 | 遇敌概率减半 Evasive Maneuvers | ~~遇敌率减半（探索用，竞技场无效）~~ 不能装备 |
| `elemental_augmentation` | 学者 | 2 | 属攻+50 Elemental Augmentation | 属攻 +50 |
| `extra_experience` | 学者 | 3 | 获得EXP提升 Extra Experience | ~~战斗后获得的经验 ×1.1（探索用，竞技场无效）~~ 不能装备 |
| `advanced_magic_master` | 学者 | 4 | 魔法强化加成 Advanced Magic Master | 自己施放大魔法化 / 硕学王的知识时，强化次数 +1 |
| `incidental_attack` | 盗贼 | 1 | 顺便战斗 Incidental Attack | 使用不造成伤害的技能后，50% 概率再普通攻击 1 次 |
| `fleetfoot` | 盗贼 | 2 | 行动速度+50 Fleetfoot | 速度 +50 |
| `ensnare` | 盗贼 | 3 | 陷阱 Ensnare | 受到物理伤害时，50% 概率让攻击者随机一项属性下降 2 回合 |
| `life_in_the_shadows` | 盗贼 | 4 | 存于黑暗 Life in the Shadows | ~~夜晚战斗后经验和 JP ×1.5（探索用，竞技场无效）~~ 不能装备 |
| `resilience` | 神官 | 1 | HP恢复量上升 Resilience | 自己技能的 HP 恢复量 ×1.3 |
| `inner_strength` | 神官 | 2 | 最大SP+50 Inner Strength | 最大 SP +50 |
| `evil_ward` | 神官 | 3 | 逃跑成功率上升 Evil Ward | ~~逃跑成功率上升（竞技场无效）~~ 不能装备 |
| `rise_again` | 神官 | 4 | 自动复活 Rise Again | 每场一次，倒下时立刻以 25% HP 复活 |
| `heighten_senses` | 猎人 | 1 | 先制攻击的概率上升 Heighten Senses | ~~先制攻击概率上升（探索用，竞技场无效）~~ 不能装备 |
| `eagle_eye` | 猎人 | 2 | 暴击+50 Eagle Eye | 暴击 +50 |
| `more_rare_monsters` | 猎人 | 3 | 稀有怪物遭遇率上升 More Rare Monsters | ~~稀有怪遭遇率上升（探索用，竞技场无效）~~ 不能装备 |
| `salt_the_wound` | 猎人 | 4 | 破防追击 Salt the Wound | 自己击破敌人时，50% 概率立刻再行动一次（不会连续触发） |
| `vigorous_victor` | 药师 | 1 | 战斗后恢复 Vigorous Victor | ~~战斗胜利后恢复 30% HP/SP（竞技场无效）~~ 不能装备 |
| `hale_and_hearty` | 药师 | 2 | 最大HP+500 Hale and Hearty | 最大 HP +500 |
| `inspiriting_break` | 药师 | 3 | 令敌人破防恢复SP Inspiriting Break | 自己击破敌人时，恢复固定 20 SP |
| `preventative_measures` | 药师 | 4 | 预防药 Preventative Measures | 开战时获得 3 次属性下降无效（每挡掉一次减 1；按次数算，日文资料和玩家实测一致） |

### 道具

效果和价格为原作数据；价格是原作商店的售价（精灵石只在新德尔斯塔平原的黑市卖），标 *内部价值* 的原作商店不卖，用原作数据表里的道具价值代替。原作资料没写、本竞技场自己定的：道具不能加成；精灵石的固定伤害不乘弱点、击破、防御倍率（圣盾照样减伤），但打中弱点会削 1 护盾；药师的「HP恢复量上升」等支援技能不影响道具。

| id | 名称 | 目标 | 效果 | 价格 |
|---|---|---|---|---|
| `healing_grape` | 恢复HP的葡萄 Healing Grape | 单个己方 | 恢复 HP 500 | 50 |
| `healing_grape_m` | 恢复HP的葡萄(大) Healing Grape (M) | 单个己方 | 恢复 HP 1250 | 260 |
| `healing_grape_bunch` | 恢复全体HP的葡萄 Healing Grape Bunch | 全体己方 | 全体恢复 HP 900 | 720（*内部价值*） |
| `inspiriting_plum` | 恢复SP的李子 Inspiriting Plum | 单个己方 | 恢复 SP 40 | 240 |
| `inspiriting_plum_m` | 恢复SP的李子(大) Inspiriting Plum (M) | 单个己方 | 恢复 SP 100 | 900 |
| `energizing_pomegranate` | 恢复BP的石榴 Energizing Pomegranate | 单个己方 | BP +1 | 300（*内部价值*） |
| `olive_of_life` | 复活的橄榄 Olive of Life | 倒下的己方 | 复活倒下的队友，HP 500 | 500 |
| `olive_of_life_m` | 复活的橄榄(大) Olive of Life (M) | 倒下的己方 | 复活倒下的队友，HP 2000 | 3000 |
| `herb_of_serenity` | 包治百病的药草 Herb of Serenity | 单个己方 | 治疗中毒（原作是治疗全部异常状态，本竞技场只有中毒和弱毒） | 600 |
| `fire_soulstone` | 火之精灵石 Fire Soulstone | 全体敌人 | 全体敌人受到 200 点火属性固定伤害 | 700 |
| `fire_soulstone_m` | 火之精灵石(大) Fire Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点火属性固定伤害 | 1700 |
| `ice_soulstone` | 冰之精灵石 Ice Soulstone | 全体敌人 | 全体敌人受到 200 点冰属性固定伤害 | 700 |
| `ice_soulstone_m` | 冰之精灵石(大) Ice Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点冰属性固定伤害 | 1700 |
| `lightning_soulstone` | 雷之精灵石 Thunder Soulstone | 全体敌人 | 全体敌人受到 200 点雷属性固定伤害 | 700 |
| `lightning_soulstone_m` | 雷之精灵石(大) Thunder Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点雷属性固定伤害 | 1700 |
| `wind_soulstone` | 风之精灵石 Wind Soulstone | 全体敌人 | 全体敌人受到 200 点风属性固定伤害 | 700 |
| `wind_soulstone_m` | 风之精灵石(大) Wind Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点风属性固定伤害 | 1700 |
| `light_soulstone` | 光之精灵石 Light Soulstone | 全体敌人 | 全体敌人受到 200 点光属性固定伤害 | 700 |
| `light_soulstone_m` | 光之精灵石(大) Light Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点光属性固定伤害 | 1700 |
| `dark_soulstone` | 暗之精灵石 Shadow Soulstone | 全体敌人 | 全体敌人受到 200 点暗属性固定伤害 | 700 |
| `dark_soulstone_m` | 暗之精灵石(大) Shadow Soulstone (M) | 全体敌人 | 全体敌人受到 1100 点暗属性固定伤害 | 1700 |

## 旅人数据

属性为原作 99 级、不带装备的基础值（本竞技场没有装备）。护盾和弱点为本竞技场设计。

| key | 旅人 | 职业 | hp | sp | pa | pd | ea | ed | acc | eva | crit | spd | 武器 | 护盾 | 弱点 | 技能 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `hikari` | 光 | 剑士 Warrior | 5781 | 145 | 342 | 313 | 256 | 228 | 313 | 228 | 285 | 285 | sword, polearm | 7 | axe, bow, ice, wind | `aggressive_slash`, `piercing_thrust`, `abide`, `enervating_slash`, `stout_wall`, `incite`, `vengeful_blade`, `brands_blade` |
| `agnea` | 爱格妮娅 | 舞娘 Dancer | 4002 | 182 | 285 | 199 | 342 | 228 | 285 | 313 | 285 | 370 | dagger | 5 | sword, polearm, lightning, dark | `lion_dance`, `ruinous_kick`, `peacock_strut`, `sweeping_gale`, `stimulate`, `dagger_dance`, `bewildering_grace`, `sealticges_seduction` |
| `partitio` | 帕特提欧 | 商人 Merchant | 4891 | 182 | 313 | 285 | 313 | 285 | 285 | 256 | 256 | 256 | polearm, bow | 6 | dagger, axe, wind, dark | `arrow_of_fortune`, `rest`, `ember`, `donate_bp`, `sidestep`, `bifelgans_bounty` |
| `osvald` | 奥兹巴尔多 | 学者 Scholar | 3557 | 218 | 256 | 256 | 370 | 342 | 285 | 285 | 228 | 256 | staff | 5 | sword, dagger, fire, lightning | `fireball`, `icewind`, `lightning_bolt`, `stroke_of_genius`, `elemental_barrage`, `advance_magic`, `alephans_wisdom` |
| `temenos` | 提米诺斯 | 神官 Cleric | 4002 | 236 | 285 | 285 | 342 | 370 | 285 | 228 | 199 | 228 | staff | 6 | polearm, wind, ice, dark | `heal_wounds`, `holy_light`, `prayer_to_the_flame`, `mystical_staff`, `luminescence`, `sacred_shield`, `revive`, `aelfrics_blessing` |
| `throne` | 斯洛妮 | 盗贼 Thief | 4447 | 145 | 313 | 228 | 285 | 228 | 313 | 342 | 285 | 342 | dagger, sword | 5 | staff, bow, fire, light | `darkest_night`, `hp_thief`, `surprise_attack`, `swift_step`, `armor_corrosive`, `shackle_foe`, `aebers_reckoning` |
| `ochette` | 欧修缇 | 猎人 Hunter | 4447 | 145 | 342 | 228 | 285 | 228 | 342 | 313 | 313 | 285 | bow, axe | 6 | sword, staff, fire, ice | `precise_shot`, `thunderbird`, `cleaving_blow`, `mercy_strike`, `take_aim`, `leghold_trap`, `abating_orb`, `draefendis_bow` |
| `castti` | 卡斯蒂 | 药师 Apothecary | 5336 | 182 | 313 | 285 | 285 | 285 | 285 | 256 | 285 | 228 | axe | 6 | polearm, staff, lightning, light | `healing_touch`, `icicle`, `rehabilitate`, `sweeping_cleave`, `poison_axe`, `replenish_health`, `weak_to_poison`, `dohters_charity`, `concoct` |

## 技能表

`target`：`enemy` 单个敌人，`enemies` 全体敌人，`random` 随机敌人（每击单独随机），`chosen` 每一击的目标由你在 `targets` 里指定，`ally` 单个己方（可以是自己），`ally_other` 自己以外的单个己方，`ally_any` 单个己方（可以是倒下的），`allies` 全体己方，`self` 自己。
`power` 是基础档位的便捷字段；实际伤害使用invocation_values和ability_ratios，不应只按power推算，`hits` 是固定打击次数。技能中文名保留当前工程用语，SP消耗按核对表，伤害档位使用随包核对参数。神技（★）必须花 3 BP 发动。


**光（剑士）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `aggressive_slash` | Aggressive Slash 五月雨斩 | 9 | random | kind=phys; type=sword; power=0.5599999999999999; boost=hits; levels=[3, 4, 5, 6]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[0.8, 1.1, 1.4, 1.7]; invocation_values=[0.7, 0.7, 0.7, 0.7] | 剑，随机攻击敌人 3/4/5/6 次 |
| `piercing_thrust` | Piercing Thrust 会心之枪 | 12 | enemy | kind=phys; type=polearm; power=1.25; boost=crit; levels=[25, 50, 75, 100]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.25, 1.25, 1.25, 1.25] | 枪，单体强力攻击，暴击率 25/50/75/100% |
| `abide` | Abide 蓄力 | 4 | self | boost=dur; levels=[3, 5, 7, 9]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 自身物攻上升 3/5/7/9 回合 |
| `enervating_slash` | Enervating Slash 无心长刀 | 7 | enemy | kind=phys; type=sword; power=0.9; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[0.9, 0.9, 0.9, 0.9] | 消除目标的正面效果，按消除数量提高此次攻击伤害 |
| `stout_wall` | Stout Wall 铁壁 | 4 | self | boost=dur; levels=[3, 5, 7, 9]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 自身物防上升 3/5/7/9 回合 |
| `incite` | Incite 挑衅 | 4 | self | boost=dur; levels=[3, 5, 7, 9]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 敌人的单体攻击全部打向自己，3 回合（加成延长） |
| `vengeful_blade` | Vengeful Blade 反击长刀 | 6 | self | boost=count; levels=[2, 3, 4, 5]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 受到物理攻击时用剑反击，2/3/4/5 次 |
| `brands_blade` | ★Brand's Blade 雷剑将布兰德的刚剑 | 30 | enemy | kind=phys; type=sword; power=10.2; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 6.0]; invocation_values=[1.7, 1.7, 1.7, 1.7] | 神技：剑，单体极强攻击 |
| `tenretsu` | Tenretsu 天裂斩 | 0 | enemy | kind=phys; type=sword; power=2.1; boost=power; hit_ratios=[999.0, 999.0, 999.0, 999.0]; ability_ratios=[1.2, 2.4, 3.6, 4.8]; invocation_values=[1.75, 1.75, 1.75, 1.75] | 潜力专属：剑，单体 1 次强力斩击 |
| `hien` | Hien 飞燕华 | 0 | enemy | kind=phys; type=sword; power=1.4; hits=2; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.4, 1.4, 1.4, 1.4] | 潜力专属：单体两次剑攻击，在本回合末追加一次行动；每回合最多追加一次 |
| `sougetsu` | Sougetsu 双月闪 | 0 | enemies | kind=phys; type=sword; power=1.1; hits=2; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.1, 1.1, 1.1, 1.1] | 潜力专属：全体先受一次剑攻击，再受一次长柄武器攻击 |

**爱格妮娅（舞娘）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `lion_dance` | Lion Dance 狮子之舞 | 4 | ally | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个队友物攻上升 2/4/6/8 回合 |
| `ruinous_kick` | Ruinous Kick 猛踢要害 | 10 | enemy | kind=phys; power=1.5; boost=power; shield_break=1; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.5, 1.5, 1.5, 1.5] | 无属性物理单体强力攻击，无视弱点削减 1 护盾 |
| `peacock_strut` | Peacock Strut 孔雀之舞 | 4 | ally | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个队友属攻上升 2/4/6/8 回合 |
| `sweeping_gale` | Sweeping Gale 旋风 | 7 | enemy | kind=elem; type=wind; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 风，单体 |
| `stimulate` | Stimulate 推波助澜 | 5 | ally_other | boost=count; levels=[1, 2, 3, 99]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 让一名其他队友的下一次行动提前 1/2/3 位/最先 |
| `dagger_dance` | Dagger Dance 短刀之舞 | 9 | enemies | kind=phys; type=dagger; power=1.1; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.1, 1.1, 1.1, 1.1] | 短剑，全体 |
| `bewildering_grace` | Bewildering Grace 百思不解之舞 | 25 | self | boost=count; levels=[1, 2, 3, 4] | 随机触发 1/2/3/4 个奇妙效果（有好有坏） |
| `sealticges_seduction` | ★Sealticge's Seduction 舞姬希尔缇吉的话 | 30 | ally | hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 神技：3 回合内，该队友的单体技能改为作用于全体（神技和只作用于自己的技能除外） |

**帕特提欧（商人）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `arrow_of_fortune` | Arrow of Fortune 幸运之箭 | 12 | enemy | kind=phys; type=bow; power=1.4; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.8, 2.6, 3.4]; invocation_values=[1.4, 1.4, 1.4, 1.4] | 弓，单体强力攻击 |
| `rest` | Rest 稍作休息 | 0 | self | boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.7, 2.5, 3.3, 4.1]; invocation_values=[0, 0, 0, 0] | 按施术者基础属防、恢复系数和等级系数恢复HP；恢复25/50/75/100 SP，解除中毒 |
| `ember` | Ember 火花 | 7 | enemy | kind=elem; type=fire; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 火，单体 |
| `donate_bp` | Donate BP BP传递 | 6 | ally_other | boost=count; levels=[1, 2, 3, 4]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 给一名其他队友 1/2/3/4 BP |
| `sidestep` | Sidestep 紧急回避 | 10 | self | boost=count; levels=[1, 2, 3, 4]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 必定闪避接下来 1/2/3/4 次物理攻击 |
| `bifelgans_bounty` | ★Bifelgan's Bounty 绅商伯比菲尔根的心眼 | 30 | enemy | kind=elem; power=7.800000000000001; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 6.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 神技：无属性单体魔法伤害；本赛事战斗中不增加赛前金钱 |

**奥兹巴尔多（学者）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `fireball` | Fireball 火焰魔法 | 14 | enemies | kind=elem; type=fire; power=1.05; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.05, 1.05, 1.05, 1.05]; tier_parameters=[[{'ratio': 1.0, 'invocation': 1.05}, {'ratio': 1.9, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}, {'ratio': 3.7, 'invocation': 1.05}], [{'ratio': 0.85, 'invocation': 1.05}, {'ratio': 1.5, 'invocation': 1.05}, {'ratio': 2.15, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}], [{'ratio': 0.75, 'invocation': 1.05}, {'ratio': 1.3, 'invocation': 1.05}, {'ratio': 1.85, 'invocation': 1.05}, {'ratio': 2.4, 'invocation': 1.05}]]; spell | 火，全体 |
| `icewind` | Icewind 冰冻魔法 | 14 | enemies | kind=elem; type=ice; power=1.05; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.05, 1.05, 1.05, 1.05]; tier_parameters=[[{'ratio': 1.0, 'invocation': 1.05}, {'ratio': 1.9, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}, {'ratio': 3.7, 'invocation': 1.05}], [{'ratio': 0.85, 'invocation': 1.05}, {'ratio': 1.5, 'invocation': 1.05}, {'ratio': 2.15, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}], [{'ratio': 0.75, 'invocation': 1.05}, {'ratio': 1.3, 'invocation': 1.05}, {'ratio': 1.85, 'invocation': 1.05}, {'ratio': 2.4, 'invocation': 1.05}]]; spell | 冰，全体 |
| `lightning_bolt` | Lightning Bolt 雷击魔法 | 14 | enemies | kind=elem; type=lightning; power=1.05; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.05, 1.05, 1.05, 1.05]; tier_parameters=[[{'ratio': 1.0, 'invocation': 1.05}, {'ratio': 1.9, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}, {'ratio': 3.7, 'invocation': 1.05}], [{'ratio': 0.85, 'invocation': 1.05}, {'ratio': 1.5, 'invocation': 1.05}, {'ratio': 2.15, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}], [{'ratio': 0.75, 'invocation': 1.05}, {'ratio': 1.3, 'invocation': 1.05}, {'ratio': 1.85, 'invocation': 1.05}, {'ratio': 2.4, 'invocation': 1.05}]]; spell | 雷，全体 |
| `stroke_of_genius` | Stroke of Genius 灵光一闪 | 5 | self | boost=count; levels=[2, 3, 4, 5]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 随机获得 2/3/4/5 个属性上升（3 回合，重复则延长） |
| `elemental_barrage` | Elemental Barrage 属性混乱 | 10 | random | kind=elem; type=random_fil; power=0.6400000000000001; boost=hits; levels=[[3, 5], [4, 6], [5, 7], [6, 8]]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[0.8, 1.1, 1.4, 1.7]; invocation_values=[0.8, 0.8, 0.8, 0.8] | 火/冰/雷随机，随机攻击敌人 3-5/4-6/5-7/6-8 次 |
| `advance_magic` | Advanced Magic 大魔法化 | 15 | ally | boost=count; levels=[2, 3, 4, 5]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 使一名队友接下来2/3/4/5次适用魔法强化为二阶；魔法强化加成另加1次 |
| `alephans_wisdom` | ★Alephan's Wisdom 硕学王阿雷芬的知识 | 30 | ally | hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 使一名队友接下来3次适用魔法强化为三阶；魔法强化加成另加1次 |

**提米诺斯（神官）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `heal_wounds` | Heal Wounds 恢复魔法 | 15 | allies | boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.4, 2.1, 2.8, 3.5]; invocation_values=[0, 0, 0, 0]; tier_parameters=[[{'ratio': 1.4, 'invocation': 1.2}, {'ratio': 2.1, 'invocation': 1.2}, {'ratio': 2.8, 'invocation': 1.2}, {'ratio': 3.5, 'invocation': 1.2}], [{'ratio': 1.4, 'invocation': 1.8}, {'ratio': 2.1, 'invocation': 1.8}, {'ratio': 2.8, 'invocation': 1.8}, {'ratio': 3.5, 'invocation': 1.8}], [{'ratio': 1.4, 'invocation': 2.4}, {'ratio': 2.1, 'invocation': 2.4}, {'ratio': 2.8, 'invocation': 2.4}, {'ratio': 3.5, 'invocation': 2.4}]]; spell; heal=按属防与技能档位计算 | 全体队友恢复 HP |
| `holy_light` | Holy Light 圣光 | 6 | enemy | kind=elem; type=light; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 光，单体 |
| `prayer_to_the_flame` | Prayer to the Flame 圣火的祈祷 | 8 | ally | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 一名队友物防与属防上升2/4/6/8回合 |
| `mystical_staff` | Mystical Staff 吸魔杖击 | 6 | enemy | kind=phys; type=staff; power=1.1; hits=2; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.8, 2.6, 3.4]; invocation_values=[1.1, 1.1, 1.1, 1.1] | 杖，单体 2 次，回复相当于伤害 10% 的 SP |
| `luminescence` | Luminescence 光明魔法 | 14 | enemies | kind=elem; type=light; power=1.05; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.05, 1.05, 1.05, 1.05]; tier_parameters=[[{'ratio': 1.0, 'invocation': 1.05}, {'ratio': 1.9, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}, {'ratio': 3.7, 'invocation': 1.05}], [{'ratio': 0.85, 'invocation': 1.05}, {'ratio': 1.5, 'invocation': 1.05}, {'ratio': 2.15, 'invocation': 1.05}, {'ratio': 2.8, 'invocation': 1.05}], [{'ratio': 0.75, 'invocation': 1.05}, {'ratio': 1.3, 'invocation': 1.05}, {'ratio': 1.85, 'invocation': 1.05}, {'ratio': 2.4, 'invocation': 1.05}]]; spell | 光，全体 |
| `sacred_shield` | Sacred Shield 守护之圣盾 | 10 | ally | boost=count; levels=[50, 65, 80, 100]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0.5, 0.65, 0.8, 1.0] | 单个队友下一次受到的伤害减少 50/65/80/100% |
| `revive` | Revive 复活魔法 | 40 | allies | boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.4, 2.1, 2.8, 3.5]; invocation_values=[0, 0, 0, 0]; tier_parameters=[[{'ratio': 1.4, 'invocation': 0.0}, {'ratio': 2.1, 'invocation': 1.2}, {'ratio': 2.8, 'invocation': 1.2}, {'ratio': 3.5, 'invocation': 1.2}], [{'ratio': 1.4, 'invocation': 1.8}, {'ratio': 2.1, 'invocation': 1.8}, {'ratio': 2.8, 'invocation': 1.8}, {'ratio': 3.5, 'invocation': 1.8}], [{'ratio': 1.4, 'invocation': 2.4}, {'ratio': 2.1, 'invocation': 2.4}, {'ratio': 2.8, 'invocation': 2.4}, {'ratio': 3.5, 'invocation': 2.4}]]; spell | 复活全体倒下队友；恢复量按属防、档位与魔法阶数计算，零BP一阶复活仅恢复1 HP |
| `aelfrics_blessing` | ★Aelfric's Blessing 圣火神爱尔福林克的指引 | 30 | ally | hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 神技：3 回合内，该队友每回合末尾额外行动一次 |

**斯洛妮（盗贼）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `darkest_night` | Darkest Night 暗夜 | 7 | enemy | kind=elem; type=dark; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 暗，单体 |
| `hp_thief` | HP Thief 吸血匕首 | 6 | enemy | kind=phys; type=dagger; power=1.1; hits=2; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.8, 2.6, 3.4]; invocation_values=[1.1, 1.1, 1.1, 1.1] | 短剑，单体 2 次，吸取伤害一半的 HP |
| `surprise_attack` | Surprise Attack 突然袭击 | 12 | enemy | kind=phys; type=sword; power=1.25; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.25, 1.25, 1.25, 1.25] | 剑，单体；本回合越早行动威力越高（第 1 个行动 2.6 倍，往后每个顺位 -0.15，最低 1.4） |
| `swift_step` | Swift Step 瞬间移动 | 4 | self | boost=dur; levels=[3, 5, 7, 9]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 自身速度上升 3 回合（加成延长） |
| `armor_corrosive` | Armor Corrosive 猫头鹰 | 4 | enemy | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个敌人物防下降 2/4/6/8 回合 |
| `shackle_foe` | Shackle Foe 蝙蝠 | 4 | enemy | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个敌人物攻下降 2/4/6/8 回合 |
| `aebers_reckoning` | ★Aeber's Reckoning 盗公子埃伯尔的钩爪 | 30 | enemies | kind=phys; type=dagger; power=7.5; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 5.0]; invocation_values=[1.5, 1.5, 1.5, 1.5] | 全体短剑攻击；以物攻计算基础伤害，再乘 (0.84 + 当前速度/500) |

**欧修缇（猎人）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `precise_shot` | Precise Shot 狙击 | 6 | chosen | kind=phys; type=bow; power=0.9; boost=hits; levels=[2, 3, 4, 5]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[0.9, 0.9, 0.9, 0.9]; invocation_values=[1.0, 1.0, 1.0, 1.0] | 弓，攻击 2/3/4/5 次，每次的目标由你指定（targets 列表，不足的重复最后一个） |
| `thunderbird` | Thunderbird 雷鸟 | 7 | enemy | kind=elem; type=lightning; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 雷，单体较强攻击 |
| `cleaving_blow` | Cleaving Blow 瓦解 | 12 | enemy | kind=phys; type=axe; power=1.4; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.4, 1.4, 1.4, 1.4] | 斧，单体强力攻击；自身物攻上升 3 回合，并按对手类型获得物防（物攻≥属攻）或属防上升 |
| `mercy_strike` | Mercy Strike 点到为止 | 4 | enemy | kind=phys; type=bow; power=0.01; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[0.01, 0.01, 0.01, 0.01] | 弓，单体；不会击倒对手（至少留 1 HP） |
| `take_aim` | Take Aim 瞄准目标 | 8 | allies | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 全体队友暴击率和命中上升 2/4/6/8 回合 |
| `leghold_trap` | Leghold Trap 黏着捕网 | 10 | enemy | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个敌人 2/4/6/8 回合内总在回合最后行动 |
| `abating_orb` | Abating Orb 化解弹 | 9 | enemy | boost=count; levels=[1, 2, 3, 4]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 清除单个敌人 1/2/3/4 个增益效果 |
| `draefendis_bow` | ★Draefendi's Bow 狩猎女王德雷芳朵的猛追 | 30 | enemies | kind=phys; type=bow; power=2.38; hits=3; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.7]; invocation_values=[1.3, 1.3, 1.3, 1.4] | 神技：弓，全体攻击 3 次 |
| `beast_claw` | Beast Claw 兽之爪 | 0 | enemies | kind=phys; power=1.8; hits=1; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.8, 1.8, 1.8, 1.8] | 潜力专属：全体一次无武器属性物理伤害 |
| `beast_fang` | Beast Fang 兽之牙 | 0 | enemy | kind=phys; power=2.4; hits=1; boost=power; shield_break=0; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.2, 2.4, 3.6, 4.8]; invocation_values=[2.0, 2.0, 2.0, 2.0] | 潜力专属：单体一次无武器属性物理伤害 |
| `beast_roar` | Beast Roar 兽之咆哮 | 0 | enemies | boost=dur; levels=[3, 4, 5, 6]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 全体敌人物防、属防下降3/4/5/6回合，并无视弱点削1盾；不造成HP伤害 |

**卡斯蒂（药师）**

| id | 名称 | SP | target | 参数 | 说明 |
|---|---|---|---|---|---|
| `healing_touch` | Healing Touch 治疗术 | 6 | ally_any | boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[2.0, 2.7, 3.4, 4.1]; invocation_values=[0, 0, 0, 0]; heal=按属防与技能档位计算 | 单个队友恢复 HP，可复活倒下的队友 |
| `icicle` | Icicle 冰柱 | 7 | enemy | kind=elem; type=ice; power=1.3; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.3, 1.3, 1.3, 1.3] | 冰，单体 |
| `rehabilitate` | Rehabilitate 健全化 | 10 | ally | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个队友免疫异常状态（中毒）2/4/6/8 回合，并解毒 |
| `sweeping_cleave` | Sweeping Cleave 斧一闪 | 9 | enemies | kind=phys; type=axe; power=1.1; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.9, 2.8, 3.7]; invocation_values=[1.1, 1.1, 1.1, 1.1] | 斧，全体 |
| `poison_axe` | Poison Axe 毒断击 | 12 | enemy | kind=phys; type=axe; power=1.4; boost=power; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 2.0, 3.0, 4.0]; invocation_values=[1.4, 1.4, 1.4, 1.4] | 斧，单体强力攻击，并使其中毒 2 回合 |
| `replenish_health` | Replenish Health 继续疗伤 | 9 | ally | boost=dur; levels=[3, 5, 7, 9]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个队友每次行动后恢复最大 HP 的 20%，3/5/7/9 回合 |
| `weak_to_poison` | Weak to Poison 施加中毒弱点 | 4 | enemy | boost=dur; levels=[2, 4, 6, 8]; hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 单个敌人 2/4/6/8 回合内弱毒：中毒结算伤害时削 1 护盾 |
| `dohters_charity` | ★Dohter's Charity 灵药公德塔的恩惠 | 30 | ally | hit_ratios=[0.0, 0.0, 0.0, 0.0]; ability_ratios=[1.0, 1.0, 1.0, 1.0]; invocation_values=[0, 0, 0, 0] | 神技：3 回合内，该队友的单体恢复技能和调合作用于全体队友 |

所有旅人通用：`attack` 普通攻击（物理，所用武器类型，威力 1.0，每 1 BP 多打 1 下），`defend` 防御。
潜力专用招式（光的 tenretsu / hien / sougetsu，欧修缇的 beast_claw / beast_fang / beast_roar）只能在同一次行动发动潜力时使用，不消耗 SP。


## 本届固定的对战适配

4v4、双方同时隐藏选人、30回合上限、全员99级且无装备/坚果；所有角色都有公开护盾和弱点。潜力以百分比显示。调合使用表中四种配方和统一材料数量，迷惑之舞使用表中有限事件，道具按表中固定效果结算。未收录的探索、召唤、昼夜和剧情机制不加入比赛。回避率上升额外增加20个百分点的落空率，陷阱减益2回合，中毒每次扣最大HP的1/6并向下取整。上述规则对双方一致，依本手册与随包参数执行。
